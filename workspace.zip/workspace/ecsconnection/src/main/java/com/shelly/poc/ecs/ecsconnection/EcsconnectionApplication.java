package com.shelly.poc.ecs.ecsconnection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcsconnectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcsconnectionApplication.class, args);
	}
}
